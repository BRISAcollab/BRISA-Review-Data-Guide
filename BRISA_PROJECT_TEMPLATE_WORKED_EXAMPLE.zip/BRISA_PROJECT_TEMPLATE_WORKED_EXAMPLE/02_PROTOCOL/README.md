# Protocol

Store working drafts separately from the approved protocol. Record dated amendments and their rationale after the protocol is finalised. The public release should contain the final protocol, registration record or link, and relevant amendments.
