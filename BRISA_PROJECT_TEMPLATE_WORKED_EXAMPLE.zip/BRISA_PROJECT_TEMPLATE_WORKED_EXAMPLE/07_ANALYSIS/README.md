# Analysis

Store analysis-ready inputs separately from extracted raw data. Scripts should run in a documented order and identify the files they read and create. Keep software and package versions in `documentation/analysis_environment.txt`.
