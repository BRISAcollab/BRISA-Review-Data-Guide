# Assessment

Use this folder for risk-of-bias, reporting-quality, or other structured assessments. Retain the tool or citation, project-specific guide, training records, reviewer entries, adjudication, final data, and data dictionary. Remove non-applicable subfolders only after recording that the assessment was not performed in the project README.
