# Deduplication record

- Software and version: Zotero 7
- Input files: `pubmed_2026-02-10.ris`; `scopus_2026-02-11.ris`
- Records before deduplication: 224
- Records after deduplication: 181
- Automatic procedure: Duplicate detection by title, DOI, and bibliographic metadata
- Manual review procedure: Uncertain pairs compared by title, authors, year, volume, and pages
- Output file: `deduplicated_records.ris`
