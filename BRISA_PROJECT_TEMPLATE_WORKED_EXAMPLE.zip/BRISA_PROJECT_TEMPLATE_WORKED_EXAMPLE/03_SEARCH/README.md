# Search

Keep search development separate from final executed strategies. Preserve each original database export unchanged. Complete the search log for every search run and document the deduplication procedure.
