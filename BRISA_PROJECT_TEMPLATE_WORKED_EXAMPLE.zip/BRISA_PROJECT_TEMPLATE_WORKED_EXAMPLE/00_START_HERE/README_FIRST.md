# Project orientation

## Project

- Full title: Effects of Compound A in preclinical models of Condition B
- Short name: COMPA-PRECLIN
- Project lead: Example Researcher
- BRISA contact: Example Coordinator
- Date started: 2026-01-12
- Current stage: Analysis completed; public-release package in preparation

## Research question

What are the effects of Compound A on Outcome X in controlled in vivo studies of Condition B?

## Registration and protocol

- Registration platform: Example registry
- Registration identifier or link: EXAMPLE-2026-001
- Final protocol: `../02_PROTOCOL/final/`

## Main tools

- Search management: Zotero
- Screening: Rayyan
- Data extraction: Microsoft Excel
- Assessment: SYRCLE-based project form
- Analysis: R

## Folder use

- `01_ADMINISTRATION/`: internal project management records.
- `02_PROTOCOL/`: protocol versions, registration, and amendments.
- `03_SEARCH/`: search development, executed strategies, exports, and deduplication.
- `04_SCREENING/`: screening instructions, reviewer work, and final decisions.
- `05_EXTRACTION/`: extraction instructions, reviewer work, final data, and dictionaries.
- `06_ASSESSMENT/`: risk-of-bias or reporting assessments, when performed.
- `07_ANALYSIS/`: analysis inputs, scripts, documentation, and outputs, when performed.
- `08_OUTPUTS/`: final flow diagrams, figures, tables, and supplementary files.
- `09_MANUSCRIPT/`: drafting and submission records.
- `10_PUBLIC_RELEASE/`: curated files prepared for public sharing.

## File conventions

- Use ISO dates: `YYYY-MM-DD`.
- Preserve original exports before editing them.
- Use stable identifiers across all datasets.
- Define every final dataset column in its data dictionary.
- Record missing data using the codes defined in the relevant guide and dictionary.

## Current status and next action

Check the curated files in `10_PUBLIC_RELEASE/` against `PUBLIC_RELEASE_CHECKLIST.md`.
