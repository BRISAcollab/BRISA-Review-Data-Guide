# Manuscript

Internal manuscript drafts, reference-library files, and submission records. These files are not automatically part of the research-data release.
