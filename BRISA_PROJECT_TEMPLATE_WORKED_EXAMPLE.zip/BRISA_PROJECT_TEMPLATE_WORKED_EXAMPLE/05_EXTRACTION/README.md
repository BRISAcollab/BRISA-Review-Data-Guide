# Data extraction

Keep extraction instructions, the blank collection form, reviewer-level work, adjudication, final curated data, and decision records distinguishable. Every final dataset must have a data dictionary using the exact column names.
