# Outputs

Store final flow diagrams, figures, tables, and supplementary materials. Retain editable or source versions when they are needed to update the output.
