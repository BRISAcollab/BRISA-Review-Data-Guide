# Screening

Store the screening guide, calibration records, original platform exports, reviewer-level decisions, adjudication, and final reconciled decisions separately. The final dataset should identify each record and include the final decision and exclusion reason where applicable.
