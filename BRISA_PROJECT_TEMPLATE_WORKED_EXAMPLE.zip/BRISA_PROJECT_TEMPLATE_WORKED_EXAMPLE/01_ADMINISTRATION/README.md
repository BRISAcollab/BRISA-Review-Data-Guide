# Administration

Internal project-management records: team roles, meeting records, timeline, and authorship decisions. Keep personal contact information and confidential discussions out of the public-release folder.
