# Licence record

This synthetic example does not assign a project licence. Before a real release, state the selected licences for documentation, data, and code and identify any third-party material that is excluded.
