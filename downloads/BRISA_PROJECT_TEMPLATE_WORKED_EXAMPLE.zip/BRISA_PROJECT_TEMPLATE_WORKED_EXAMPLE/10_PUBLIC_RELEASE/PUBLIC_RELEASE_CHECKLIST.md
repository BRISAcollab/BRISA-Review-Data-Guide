# Public-release checklist

- [ ] Files are final and named consistently.
- [ ] The public README describes every folder and file.
- [ ] Each shared dataset has a data dictionary.
- [ ] Analysis scripts identify inputs, outputs, and run order.
- [ ] Licences are stated for data, documentation, and code as applicable.
- [ ] Personal and confidential information has been removed.
- [ ] Article PDFs and non-redistributable exports have been removed.
- [ ] Links and persistent identifiers have been checked.
- [ ] The release has been reviewed by the project lead.
