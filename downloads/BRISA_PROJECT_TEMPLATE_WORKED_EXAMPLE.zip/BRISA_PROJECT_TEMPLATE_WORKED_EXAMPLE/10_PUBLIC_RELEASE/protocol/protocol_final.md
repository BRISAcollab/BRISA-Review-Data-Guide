# Protocol: Effects of Compound A in preclinical models of Condition B

This synthetic protocol is included only to illustrate file placement.

## Objective

To estimate the effect of Compound A on Outcome X in controlled in vivo studies of Condition B.

## Eligibility

Eligible studies compare Compound A with a concurrent vehicle or untreated control in a mammalian in vivo model and report sufficient quantitative data for Outcome X.

## Synthesis

Compatible outcomes will be expressed as standardised mean differences and synthesised using a random-effects model when at least three independent experiments are available.
