# Screening guide

## Eligibility criteria

### Population or model

Controlled in vivo mammalian models of Condition B.

### Intervention or exposure

Compound A or its coded synonym A-101, administered before outcome measurement.

### Comparator

Concurrent vehicle, sham treatment, or untreated control.

### Outcomes

Outcome X measured as a continuous group-level outcome.

### Study design

Original controlled experiment reporting primary data. Reviews, protocols, editorials, conference abstracts without sufficient data, and human studies are excluded.

## Stage-specific rules

### Title and abstract screening

Include when the record may meet all criteria. Move uncertain records to full-text screening rather than excluding on an incomplete abstract.

### Full-text screening

Confirm all eligibility domains from the full report. Apply one primary exclusion reason using this order: wrong publication type; wrong population or model; wrong intervention; wrong comparator; no eligible outcome; insufficient report.

## Exclusion reasons

1. Wrong publication type
2. Wrong population or model
3. Wrong intervention
4. Wrong comparator
5. No eligible outcome
6. Insufficient report

## Ambiguous cases

When a treatment name is unclear, check the methods and supplementary material before adjudication. Record the decision in the screening notes without copying extended article text.
