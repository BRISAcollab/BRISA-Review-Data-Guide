# Analysis run order

1. `01_prepare_data.R` — reads the final extracted dataset and creates `analysis_data.csv`.
2. `02_run_meta_analysis.R` — reads `analysis_data.csv` and creates the model summary and forest plot.

## Reproduction notes

- Working directory: project root
- Required software: R 4.5 or later
- Expected outputs: `model_summary.txt`; `forest_plot.png`
- Manual steps: none after file paths are checked
