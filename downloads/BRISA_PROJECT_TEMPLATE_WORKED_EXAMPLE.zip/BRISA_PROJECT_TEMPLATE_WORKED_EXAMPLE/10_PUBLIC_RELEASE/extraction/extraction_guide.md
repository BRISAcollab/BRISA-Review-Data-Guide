# Data extraction guide

For each variable, define what should be extracted, the permitted sources, allowed values, units, conversions, missing-value codes, and rules for resolving multiple eligible values. Keep variable names identical to the extraction form and data dictionary.

## General rules

- Extract what is reported; do not infer unreported values unless a documented calculation is permitted.
- Record the source location for values that require interpretation.
- Preserve original units and document standardisation in a separate derived variable.
- Record changes to extraction rules in the decision log.
