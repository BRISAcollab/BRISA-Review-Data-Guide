# Public release: Compound A preclinical review

This synthetic release demonstrates how final, shareable files are selected from the internal workspace. It is not a copy of the full project folder and contains no real study data.

## Contents

- `protocol/`: final protocol, registration record, and relevant amendments.
- `search/`: executed search strategies and search log.
- `screening/`: screening guide and final reconciled decisions.
- `extraction/`: extraction guide, final data, and data dictionary.
- `assessment/`: assessment guide, final judgments, and data dictionary.
- `analysis/`: analysis inputs, scripts, run order, and outputs.
- `outputs/`: final figures and tables needed to interpret the project.

## Related publication

No publication. This is a synthetic worked example.

## Licence

Add the licences selected for documentation, data, and code before release.

## Minimum contents

- final protocol and registration record or link;
- relevant protocol amendments;
- final executed search strategies and search log;
- screening guide and final screening decisions;
- extraction guide, final extracted data, and data dictionaries;
- assessment guide and final data, when an assessment was performed;
- analysis inputs, scripts, run order, and relevant outputs, when an analysis was performed;
- final outputs needed to interpret the project;
- project README and applicable licences.

## Do not publish by default

- full-text article PDFs;
- personal contact information;
- confidential administrative or meeting records;
- training files and working drafts;
- credentials, tokens, or private links;
- database or platform exports whose redistribution is not permitted.
