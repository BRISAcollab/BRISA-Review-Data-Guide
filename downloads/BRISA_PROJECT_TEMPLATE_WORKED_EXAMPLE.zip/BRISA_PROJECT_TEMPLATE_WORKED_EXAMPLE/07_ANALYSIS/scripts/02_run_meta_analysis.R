# Synthetic BRISA worked example
# Input: 07_ANALYSIS/input_data/analysis_data.csv
# Outputs: 07_ANALYSIS/outputs/model_summary.txt and forest_plot.png

data <- read.csv("07_ANALYSIS/input_data/analysis_data.csv")
print(data)
message("Worked example: model code is intentionally minimal and does not represent a scientific analysis.")
