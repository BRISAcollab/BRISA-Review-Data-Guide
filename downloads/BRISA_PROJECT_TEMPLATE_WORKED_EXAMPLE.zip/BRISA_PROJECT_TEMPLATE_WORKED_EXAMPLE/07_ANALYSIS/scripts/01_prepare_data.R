# Synthetic BRISA worked example
# Input: 05_EXTRACTION/final_data/extracted_data_final.csv
# Output: 07_ANALYSIS/input_data/analysis_data.csv

message("Worked example: replace this placeholder with the documented project transformation code.")
