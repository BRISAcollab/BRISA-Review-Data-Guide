# BRISA worked example

This package illustrates the BRISA project structure using a fictional systematic review of Compound A in preclinical models of Condition B.

All study records, values, identifiers, dates, and results in this package are synthetic. They are provided to demonstrate file organisation and should not be used in an actual review.

Editable internal documents are supplied as `.docx` for use in Word or import into Google Docs. Public-release documentation uses `.md`, public tabular data use `.csv`, and analysis scripts remain in their native format.

Folders marked as conditional in the project README may be removed when the corresponding activity is not performed. Do not remove the main numbered folders while the project is active.

Blank spreadsheet templates are stored in the relevant workflow folders. Public-release copies should be prepared only after the final project files have been curated.

Do not store personal contact details, confidential records, passwords, access tokens, or copyrighted article PDFs in the public-release folder.
