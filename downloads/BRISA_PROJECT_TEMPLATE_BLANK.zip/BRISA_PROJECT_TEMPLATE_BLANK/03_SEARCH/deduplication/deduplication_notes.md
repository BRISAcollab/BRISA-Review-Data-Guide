# Deduplication record

- Software and version: [complete]
- Input files: [complete]
- Records before deduplication: [complete]
- Records after deduplication: [complete]
- Automatic procedure: [complete]
- Manual review procedure: [complete]
- Output file: [complete]
