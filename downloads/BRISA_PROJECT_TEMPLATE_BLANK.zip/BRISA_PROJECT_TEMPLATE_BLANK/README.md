# BRISA project template

Use this folder as the starting structure for a BRISA systematic review or meta-analysis project.

The complete working record must remain in the project folder within the BRISA Google Drive. Rename the root folder using the project short name, then complete `00_START_HERE/README_FIRST.md`.

Folders marked as conditional in the project README may be removed when the corresponding activity is not performed. Do not remove the main numbered folders while the project is active.

Blank spreadsheet templates are stored in the relevant workflow folders. Public-release copies should be prepared only after the final project files have been curated.

Do not store personal contact details, confidential records, passwords, access tokens, or copyrighted article PDFs in the public-release folder.
