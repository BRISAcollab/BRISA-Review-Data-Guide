# Project orientation

## Project

- Full title: [complete]
- Short name: [complete]
- Project lead: [complete]
- BRISA contact: [complete]
- Date started: [YYYY-MM-DD]
- Current stage: [complete]

## Research question

[Write the review question in one or two sentences.]

## Registration and protocol

- Registration platform: [complete]
- Registration identifier or link: [complete]
- Final protocol: `../02_PROTOCOL/final/`

## Main tools

- Search management: [complete]
- Screening: [complete]
- Data extraction: [complete]
- Assessment: [complete or not applicable]
- Analysis: [complete or not applicable]

## Folder use

- `01_ADMINISTRATION/`: internal project management records.
- `02_PROTOCOL/`: protocol versions, registration, and amendments.
- `03_SEARCH/`: search development, executed strategies, exports, and deduplication.
- `04_SCREENING/`: screening instructions, reviewer work, and final decisions.
- `05_EXTRACTION/`: extraction instructions, reviewer work, final data, and dictionaries.
- `06_ASSESSMENT/`: risk-of-bias or reporting assessments, when performed.
- `07_ANALYSIS/`: analysis inputs, scripts, documentation, and outputs, when performed.
- `08_OUTPUTS/`: final flow diagrams, figures, tables, and supplementary files.
- `09_MANUSCRIPT/`: drafting and submission records.
- `10_PUBLIC_RELEASE/`: curated files prepared for public sharing.

## File conventions

- Use ISO dates: `YYYY-MM-DD`.
- Preserve original exports before editing them.
- Use stable identifiers across all datasets.
- Define every final dataset column in its data dictionary.
- Record missing data using the codes defined in the relevant guide and dictionary.

## Current status and next action

[Update this section when the workflow stage changes.]
