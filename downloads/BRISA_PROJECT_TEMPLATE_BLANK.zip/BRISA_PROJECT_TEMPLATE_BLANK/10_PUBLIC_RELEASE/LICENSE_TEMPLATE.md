# Licence record

Complete this file before public release.

- Documentation licence: [complete]
- Data licence: [complete]
- Code licence: [complete or not applicable]
- Third-party materials excluded from these licences: [complete]

Do not apply a licence to third-party material unless the project has the right to do so.
