# Public release

This folder is assembled from final, shareable files in the internal workspace. It is not a copy of the full project folder.

## Minimum contents

- final protocol and registration record or link;
- relevant protocol amendments;
- final executed search strategies and search log;
- screening guide and final screening decisions;
- extraction guide, final extracted data, and data dictionaries;
- assessment guide and final data, when an assessment was performed;
- analysis inputs, scripts, run order, and relevant outputs, when an analysis was performed;
- final outputs needed to interpret the project;
- project README and applicable licences.

## Do not publish by default

- full-text article PDFs;
- personal contact information;
- confidential administrative or meeting records;
- training files and working drafts;
- credentials, tokens, or private links;
- database or platform exports whose redistribution is not permitted.
