# Screening guide

## Eligibility criteria

### Population or model

[complete]

### Intervention or exposure

[complete]

### Comparator

[complete]

### Outcomes

[complete]

### Study design

[complete]

## Stage-specific rules

### Title and abstract screening

[complete]

### Full-text screening

[complete]

## Exclusion reasons

List the allowed full-text exclusion reasons in the order in which they should be applied.

## Ambiguous cases

Document recurring decisions and examples without including copyrighted article text.
